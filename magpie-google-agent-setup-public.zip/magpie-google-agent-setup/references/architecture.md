# 架构、来源和验证范围

两条客户端分支共用「Google 账号 → 本机 agy → agy-cli 插件 → 本机 Magpie 网关」，但网关对外的 API 不同。

```text
Claude Desktop / Claude Code
  → 本机 Magpie 网关（Anthropic Messages，地址通常为 http://127.0.0.1:3425，不含必须加 /v1）
  → agy-cli provider（多个独立账号，Magpie 路由）
  → 对应账号的官方 agy ACP 进程
  → Google 服务

Codex CLI / 应用
  → 本机 Magpie 网关（OpenAI Responses，地址通常为 http://127.0.0.1:3425/v1）
  → 同一套 agy-cli provider 与路由
  → 对应账号的官方 agy ACP 进程
  → Google 服务
```

执行本指南的代理只协助配置与验收，通常不在上述请求链路中。被配置的是 Claude Desktop、Claude Code 和／或 Codex，不是「任意客户端」。若要把其他产品接到 Magpie，需要该产品自己的、经过验证的接入说明；本文不提供未查证的路径，也不宣称模型可直连那些产品。

网络代理是 agy 到 Google 的传输选择，不是登录账号池本身。客户端 → 本机网关无需经过美国中转服务器；如果用户自己配置远端 Magpie，则另行检查部署与访问保护。使用这些客户端期间，本机 Magpie（或官方文档中的 `magpie daemon install` 守护进程）需要在运行，因为网关随应用提供。

原生多账号减少了旧方案的 WSL 用户、桥接端口与 worker 生命周期管理，但不能消除 Google 地区、验证、额度和模型容量限制。账号切换也不保证已输出一半的流可以透明恢复。

## 2026-11-24 核实结论（只依据上游文档，未做实机调用）

以下结论来自当日查阅的官方或插件文档，**不是**本包的端到端实测结果。

1. **Magpie 网关同时提供多种 API。** [Integrate](https://usemagpie.ai/docs/integrate) 写明默认监听 `127.0.0.1:3425`（端口以本机 `settings.json` 为准），并列出 `/v1/responses`（OpenAI Responses）、`/v1/chat/completions`、`/v1/messages`（Anthropic Messages）和 `/v1/models`。请求在供应商已讲该 API 时直通，否则由网关翻译，文档声称包含流式、工具调用、图片和推理。
2. **Codex 只讲 OpenAI Responses。** Magpie 的 [Codex 文档](https://usemagpie.ai/docs/codex-models) 写明 “Codex speaks one API, OpenAI Responses”，并由 Magpie 把网关接到 Codex，写入 `~/.codex/config.toml`。当供应商本身不提供 Responses 时，由 Magpie 翻译请求与回复，文档声称包含流式和工具调用。官方示例中的形状为 `model_provider = "magpie"`、`base_url = "http://127.0.0.1:3425/v1"`、`wire_api = "responses"`；网关 Key 由 Magpie 写入该表，供应商密钥留在 Magpie。该页明确说不要自己写 `[model_providers]`，也不要导出 `OPENAI_BASE_URL`。回滚命令为 `magpie codex default`。切换后需重启 Codex 应用并新开会话。已登录 ChatGPT 时，Magpie 主要通过 `openai_base_url` 把自身模型加进 `/model`，OpenAI 自带模型仍走用户的 ChatGPT 登录；未登录或仅用 API key 时，Magpie 成为 provider，并用旁边的 `magpie-models.json` 目录。该页将 Copilot 与 **Antigravity accounts** 列入可在 Codex 中使用的来源。
3. **Codex 官方配置也要求 Responses。** [Configuration Reference](https://learn.chatgpt.com/docs/config-file/config-reference) 写明 `model_providers.<id>.wire_api` 的唯一受支持值为 `responses`，省略时即为此默认值。[Advanced Configuration](https://learn.chatgpt.com/docs/config-file/config-advanced) 与 [Sample Configuration](https://learn.chatgpt.com/docs/config-file/config-sample) 给出自定义 provider 的 `base_url`、`wire_api`、`env_key` 等键。本包的主流程仍是让 Magpie 写配置，而不是手写一套未经验证的键。
4. **Claude 分支与 Codex 不是同一套配置。** [Claude Code 文档](https://usemagpie.ai/docs/claude-code-models) 写明 Claude Code 只讲 Anthropic Messages，Magpie 写入 `~/.claude/settings.json` 的 `ANTHROPIC_BASE_URL` 与 `ANTHROPIC_AUTH_TOKEN`（后者是网关 Key，不是厂商密钥）。命令为 `magpie claude <provider>/<model>`，回滚为 `magpie claude default`。该页将 Antigravity 账号列为可用来源，但示例前缀写成 `antigravity/…`。[Claude Desktop 文档](https://usemagpie.ai/docs/claude-desktop) 写明 Desktop 的第三方网关模式指向 `http://127.0.0.1:3425`，网关在此讲 Anthropic Messages；命令为 `magpie claude-desktop magpie`，回滚为 `magpie claude-desktop default`，修改后须完全退出再打开 Desktop。官方还写明：经 Magpie 接入时，Claude Code 的 Code Mode 不会开启。
5. **当前 Google 账号路径应使用 agy-cli 插件，而不是已退役的直接登录。** [Subscriptions](https://usemagpie.ai/docs/subscriptions) 写明安装 `@magpie-community/opencode-agy-cli-auth`，由你安装并登录的 agy CLI 发出请求，因而 Google 看到的是 agy 自己的请求；在 Magpie 里直接登录 Antigravity 已退役，那种方式会被 Google 封号。插件 [README](https://github.com/magpie-community/plugins/blob/main/packages/agy-cli/README.md) 进一步写明：装好后 provider id 是 `agy-cli`，模型写成 `agy-cli/<模型>`；插件接收 Anthropic Messages，再交给 `agy acp`；模型列表以 ACP 会话里实际向该客户端开放的选项为准，不能用未开放的 `agy models` 条目代替。核对当日 [package.json](https://github.com/magpie-community/plugins/blob/main/packages/agy-cli/package.json) 仍为 0.1.116，宿主声明 `>=0.1.4246`。main 是可变开发分支，不等于已发布 npm 版本。
6. **前缀与风险不要写死。** [Get started](https://usemagpie.ai/docs/start) 与部分 Claude／Gemini 页面仍写 `antigravity/…` 和 `magpie accounts add antigravity`，同时又警告 Google 可能暂停它认为在 Antigravity 之外使用的账号。本包以插件 README 与 Subscriptions 的现行安装方式为准，并以本机 `magpie models` 的实际 id 为准。插件不能保证账号不受限制。
7. **不要把 Gemini API 密钥路径与 Google 账号路径混为一谈。** [Gemini 文档](https://usemagpie.ai/docs/gemini) 另有 `google/…`（AI Studio 密钥）和 `gemini/…`（Code Assist）等官方路径，其中写明 Codex 只讲 Responses、由 Magpie 翻译到 Gemini 的 Chat Completions。那是另一套供应商，不是本包主流程的 agy-cli 账号。
8. **仍属条件支持、必须实机验收的部分：** Codex 经 Magpie 翻译后再进入 agy-cli（插件原生是 Anthropic Messages）这条完整链路，本包未实测；Codex 自带工具、流式、思考摘要、会话续接、多账号切换在 Codex 上的表现未实测；插件 README 在提示词改写（cloak）处提到 Codex 的系统行会被 Google 拒绝并改写，这说明该路径被考虑过，但不等于已经验收。未得到目标客户端上的真实请求证据前，不得写成「已支持全部 Codex 功能」。

其他仍有效的来源：

- [agy-cli 中文文档](https://github.com/magpie-community/plugins/blob/main/packages/agy-cli/README.md)
- [插件包信息](https://github.com/magpie-community/plugins/blob/main/packages/agy-cli/package.json)
- [Magpie 插件机制](https://usemagpie.ai/docs/plugins)
- [Magpie 项目](https://github.com/yetone/magpie)
- [Google Antigravity CLI](https://github.com/google-antigravity/antigravity-cli)
- [Claude Auto 模式说明](https://code.claude.com/docs/en/auto-mode-classifier-billing.md)

本包只更新了文档与可选 Skill 元数据，整理时没有升级正在运行的 Magpie、重新登录账号、执行生产迁移，也没有向网关或 Google 发出测试请求。旧方案或 Claude 分支曾成功，不等于 Codex 分支已经在本机完成验收。每次部署都记录实际安装版本与逐项验证结果。
