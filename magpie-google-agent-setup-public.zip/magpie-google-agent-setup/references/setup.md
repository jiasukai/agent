# 安装与登录（共用步骤）

本节处理 Magpie、agy-cli 插件和 Google 账号，是 Claude 与 Codex 两条分支的共同前提。配好账号后，再分别进入：

- Claude Desktop／Claude Code：[clients-claude.md](clients-claude.md)
- Codex CLI／应用：[clients-codex.md](clients-codex.md)

本节中的命令在用户同意后，由具备终端权限的执行代理在目标机运行，或由用户自己在本机执行。没有本机工具的执行代理应口述步骤，并根据用户回传的版本与界面信息继续，不要假装命令已经执行。本节只给出已有依据的 Magpie／官方安装来源，不添加其他产品未经查证的 CLI 安装路径。

Magpie 界面中的 Agents 页用于给被配置客户端选择网关和模型，不要把它理解成「执行本指南的代理的设置页」。

## 发现与安装

先查本机程序、版本及现有配置。已有可用环境先备份待修改文件，安装盘符按用户选择。新机从 https://usemagpie.ai/ 和 Google 官方 Antigravity CLI 文档安装相应系统／架构的版本；下载时核对官方校验信息，不捆绑二进制或盲跑远程安装脚本。原生多账号路线不需要 WSL、Linux 用户、额外 Python 服务或服务器 Sub2API，也不要另外搭建翻译代理。

安装插件可使用：

```sh
magpie plugin add @magpie-community/opencode-agy-cli-auth
```

已有插件优先通过 Plugins 页更新该插件，先记录原版本与回滚方式。不要为了更新一个插件默认更新所有插件。当前上游 package 声明 Magpie >=0.1.4246，但这只是宿主下限，不证明该最低版本包含所有账号界面；以实际 Add another account、独立身份与调用验收为准。不要假定某个 Git main 的版本已经发布到 npm。

不要为新安装使用已退役的「在 Magpie 里直接登录 Antigravity」（部分旧文档中的 `magpie accounts add antigravity`）。上游说明那种方式会被 Google 封号。若 Providers 页提示把旧 Antigravity 插件账号移到 agy-cli，按页面上的 Move 或插件文档中的导入方式处理，不要自动搬运私有 token 文件。

agy 缺失时，当前插件可在登录阶段从 Google 官方来源安装并校验；已有 agy 的发现优先级和 AGY_PATH 以当前文档为准。已有安装过旧时先比较当前 release，再安排升级。不要永久固定早期 agy 1.5.9，也不要在正在执行工具时替换二进制。

## 登录多个账号

1. Providers → Antigravity (local agy CLI) / agy-cli → Sign in。只在 Google 官方页面输入登录与验证资料。执行代理在此必须停下来，由账号本人完成认证。
2. 完成后核对 Magpie 中邮箱和模型；登录网页成功不是实际模型调用成功。接着运行 `magpie models`（或在界面中打开模型列表），记录**实际出现的 provider 前缀和型号**，后续配置只使用这份列表。当前插件文档写的是 `agy-cli/<模型>`；若本机显示其他前缀，以本机为准，不要臆造型号。
3. Add another account → 添加另一个 Google 账号。每次独立完成授权，并核对新增行属于另一个邮箱。
4. 为每个账号核对其实际开放的目标模型、额度与可见性。重复即可添加更多账号，不需要新增 WSL worker。

当前插件为新增账号维护独立 agy 主目录；原系统账号也可有插件保存的副本。不要手动替换 Windows 共享凭据管理器项目来实现轮换。插件文档提到旧版本未保留的账号副本需要重新登录；不能承诺升级后找回所有旧账号。

不要默认导入旧 token 文件。迁移时优先官方重新登录；如用户明确选择插件自带导入功能，由该功能处理，不在对话或脚本输出刷新令牌。

Google 登录凭证与稍后写入 Claude／Codex 配置里的网关 Key 不是同一份密钥。前者不要导出；后者由 Magpie 写入对应客户端，也不要复制进本仓库或对话。

## 与其他 Google 来源的区别

本包主流程是「Google 账号 + 本机 agy + agy-cli 插件」。Magpie 另外还支持 Google Gemini API 密钥（文档中的 `google/…`）和 Gemini Code Assist 登录（`gemini/…`），见 [Gemini 文档](https://usemagpie.ai/docs/gemini)。那是不同的供应商与鉴权方式，不要把密钥路径的命令或型号套用到 agy-cli 账号上。
