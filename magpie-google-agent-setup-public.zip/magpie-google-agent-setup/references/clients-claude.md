# 将 Google 账号接入 Claude Desktop／Claude Code

在完成 [setup.md](setup.md) 的登录，并已用 `magpie models` 确认实际模型 id 之后，再配置这一分支。本节只覆盖 Claude Desktop 与终端里的 Claude Code。不要把这里的成功当成 Codex 已配置完成。

本节命令在用户同意后执行；改配置前备份将被修改的文件，备份放到本仓库之外。没有本机工具的执行代理改为口述步骤。

## 接入 Claude Desktop

先在 Magpie 的 Agents 页找到 Claude Desktop，选择 magpie 网关，或按本机 help 使用：

```sh
magpie claude-desktop magpie
```

完全退出再打开 Desktop，让它读取新的网关配置与模型列表。默认网关常为 `http://127.0.0.1:3425`，使用实际配置。按 [Claude Desktop 文档](https://usemagpie.ai/docs/claude-desktop)，此模式下 Desktop 把请求发到该网关，网关讲 Anthropic Messages，再翻译给所选模型。网关认证 Key 与 Google OAuth 是不同凭证。不要手写源电脑的 DPAPI 配置、固定散列模型别名或 CC Switch 配置，也不要把密钥写进仓库。

在 Desktop 选择本机列表里真实开放的模型；如需 Code 页默认 Opus 档位使用某个模型，通过 Agents 页配置 tier。以下只是语法示例，`<actual-model-id>` 必须替换为 `magpie models` 中该账号实际开放的 id（常见形态为 `agy-cli/<id>`，以本机为准）：

```sh
magpie claude-desktop opus agy-cli/<actual-model-id>
```

需要 Sonnet／Haiku 时同理，先检查当前 help。不要把所有档位默默指向不同模型或 Flash；降级需要显式显示实际模型。修改后重启 Desktop。回滚为 `magpie claude-desktop default` 后重启；这会切回 Anthropic 登录环境。

## Claude Code 终端

与 Desktop 单独检查。按 [Claude Code 文档](https://usemagpie.ai/docs/claude-code-models)，在 Magpie 的 Agents 页为 Claude Code 选择模型，或在用户同意并备份 `~/.claude/settings.json` 后使用：

```sh
magpie claude agy-cli/<actual-model-id>
```

其中型号同样必须来自本机列表。Magpie 会改 `~/.claude/settings.json` 中它需要的键，包括 `env.ANTHROPIC_BASE_URL`（网关地址）和 `env.ANTHROPIC_AUTH_TOKEN`（网关 Key，不是 Google 令牌）。不要自己导出或改写这些变量作为主流程，也不要把密钥写进仓库。已有会话会保持启动时的模型，需新开会话。验证实际请求地址及模型；不要假定 Desktop 配置自动控制所有终端。避免 CC Switch、启动脚本和 Magpie 同时改写同一组环境变量。若 shell 里已有 `CLAUDE_CODE_USE_BEDROCK` 一类云开关，官方说明会让请求绕开 Magpie，需先按官方文档处理。

回滚为 `magpie claude default`。官方说明：经 Magpie 接入时，Claude Code 的 Code Mode 不会开启；不要把它列为本路径的验收项。

本节不把同一套步骤扩展到其他未经验证的客户端或终端。

## 本分支验收

两账号逐个真实文字测试 → 该 Claude 客户端两轮工具调用 → 多轮最新指令测试 → 安全的切换测试 → 重启复测。通过 Routing／用量记录核对实际选中账号、目标模型、状态和重试。切换失败要检查每个账号，而非反复创建会话或宣布两账号都无额度。未在 Desktop 或终端 Claude Code 里真正发过请求时，不宣称本分支完成。
