# 故障定位

先确认失败发生在哪一条客户端分支，再按对应链路检查：

- Claude Desktop／Claude Code：被配置的 Claude 客户端 → Magpie 网关（Anthropic Messages）→ 当前账号的 agy → Google
- Codex CLI／应用：被配置的 Codex → Magpie 网关（OpenAI Responses，通常为 `/v1`）→ 当前账号的 agy → Google

这里的客户端不是执行本指南的代理。记录时间、版本、模型、脱敏账号标识与原始错误。不要把所有 429、空结束或重连都归因于限额。也不要把一条分支的失败直接抄成另一条分支的结论。

| 证据 | 判断与下一步 |
|---|---|
| 429，明确 quota reached / Individual quota reached，含 reset 时间 | 当前账号对应额度池耗尽；核对可用备选账号、同模型资格和冷却。尊重服务器恢复时间，不连续重试。 |
| 429，仅 Resource exhausted | 可能有多种原因；对照原始错误、用量、短请求和实际失败请求，不能直接断言额度用完。 |
| 403 VALIDATION_REQUIRED | 用户在 Google 官方页面完成要求，再重新登录受影响账号；验证成功页不等于模型接口已恢复。不要重复消费授权码。执行代理在此停下来，把认证交给账号本人。 |
| 400 User location is not supported | 账号／出口资格检查失败；核对请求实际代理链。IP 查询显示美国不能证明 Google 识别一致。 |
| 503 No capacity available for model | 该模型容量不足；与个人额度耗尽分开。明确提示后再选择替代模型。 |
| 客户端 Credentials rejected | 先分清拒绝来自该客户端里的**网关 Key**，还是 agy／Google 上游。不要未经确认就轮换所有密钥，也不要把 Google 令牌写进 Claude 或 Codex 配置。 |
| HTTP 200 但正文是错误，或无内容 end_turn | 不能计成功；核对 SSE、工具事件、上游日志和版本。 |
| 只有部分账号的某模型失败 | 检查逐账号模型目录，不能用账号并集替代资格检查。 |
| 长会话忽略新消息，新会话正常 | 检查历史预算、resume／replay 和最新轮次，不把模型的 1M 上下文当作 ACP 传输容量。 |
| Auto 安全确认等待，动作未执行 | 打开**被配置客户端**的确认通知并回答；文字「继续」不等于点击弹窗 Continue。通知缺失时可用手动审批定位，不能绕过权限检查。 |
| Claude 已可用，但 Codex 的 `/model` 没有所选型号 | 确认改的是 Codex 行而不是 Claude 行；重启 Codex 应用并新开会话；确认 Magpie 正在运行。不要把 Claude 的 `ANTHROPIC_*` 变量套到 Codex。 |
| 已选模型但 Codex 仍走 OpenAI 自带型号，或经 Magpie 的线程打不开 | 核对本机 `config.toml` 是否符合 Magpie 官方形状，以及当前是 ChatGPT 登录还是 Magpie 作为 provider。官方说明：已有线程会保持启动时的 provider。不要手写未记录的键。 |
| 与提示词相关的 400／429，尤其在 Codex | 插件文档提到部分 Codex／GPT-5 风格系统行会被 Google 拒绝，并由插件改写。记录脱敏后的错误原文和插件／agy 版本；不要再加一层身份伪装或关闭安全检查。 |
| `magpie models` 没有要用的型号，或前缀不是预期的 `agy-cli` | 以本机列表为准。确认登录的是 agy-cli 插件而不是已退役的直接 Antigravity 登录；确认该型号在 ACP 会话里已向当前客户端开放，而不是仅出现在 `agy models`。 |

遇到提示词兼容问题，检查插件当前默认行为及发行说明；不要自行制作身份伪装或关闭安全检查的补丁。上游问题报告是诊断线索，不是已确认影响本机的事实。

采集请求内容前先最小化范围；正文、系统提示词、工具输出可能含整个项目和秘密。默认只记录状态、耗时、账号标识及错误，MCP trace 仅按需临时开启，脱敏后才分享。不要将真实失败请求、OAuth 链接、网关 Key 或完整日志放入 GitHub issue。
