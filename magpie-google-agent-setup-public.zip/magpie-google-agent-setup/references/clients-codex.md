# 将 Google 账号接入 Codex

在完成 [setup.md](setup.md) 的登录，并已用 `magpie models` 确认实际模型 id 之后，再配置这一分支。本节配置的是 **Codex CLI／应用作为目标客户端**，让它通过本机 Magpie 网关调用 Google 账号开放的模型。这与「把本 Skill 装进 Codex 的 skills 目录」不是同一步骤。

也不要把 Claude 分支的成功，或 `magpie models` 里看得见型号，当成 Codex 已经可用。

## 上游已写明的能力与边界

依据 [Codex 文档](https://usemagpie.ai/docs/codex-models) 与 [Integrate](https://usemagpie.ai/docs/integrate)：

- Codex 只讲 OpenAI Responses。当前 [Codex 配置参考](https://learn.chatgpt.com/docs/config-file/config-reference) 中，`wire_api` 的唯一受支持值也是 `responses`。只提供 Chat Completions、而没有经网关翻译到 Responses 的路径，不能当作可直接给 Codex 使用。
- Magpie 本机网关提供 `/v1/responses`。供应商本身不讲 Responses 时，由网关翻译请求和回复；文档声称包含流式和工具调用。agy-cli 插件的 README 写明它接收 Anthropic Messages，因此 Codex → 网关 → agy-cli 依赖这次翻译。这是文档中的能力，本包未做实机验证。
- 同一页把 Antigravity accounts 列为可在 Codex 中使用的来源。当前安装方式是 agy-cli 插件；本机模型 id 以 `magpie models` 为准，常见形态为 `agy-cli/<实际模型>`，不要臆造型号。
- 主流程是在 Magpie 的 Agents 页选中 Codex 行的模型，或运行下文已写明的 `magpie codex` 命令，由 Magpie 改 `~/.codex/config.toml`。官方 FAQ 写明：不要自己写 `[model_providers]`，也不要导出 `OPENAI_BASE_URL`。

## 备份

在用户同意后，把将被修改的 `~/.codex/config.toml`（以及若已存在的旁边的 `magpie-models.json`）复制到本仓库之外。备份可能含网关 Key，不要提交、不要贴进对话全文。Windows 路径通常在 `%USERPROFILE%\.codex\` 下，以本机为准。

## 选择模型并写入

1. 确认 Magpie 正在运行。官方说明：Codex 经 Magpie 使用模型时，网关随应用提供；需要无窗口常驻时，使用官方文档中的 `magpie daemon install`，不要改用未经验证的第三方进程。
2. 在 `magpie models` 的输出里选出该 Google 账号实际开放的目标型号，记作 `<actual-model-id>`。不要使用本文未给出的具体 Gemini／Claude 型号字符串。
3. 在 Agents 页打开 **Codex** 那一行，选中该型号；或在用户同意后执行：

```sh
magpie models
magpie codex agy-cli/<actual-model-id>
```

若本机列表的前缀不是 `agy-cli`，改用列表里的实际前缀，不要强行改写。需要设置推理档位时，先核对 `magpie codex --help` 或界面上的 effort 控件；官方文档中有 `magpie codex effort high` 的写法，仅在本机 help 仍提供时使用。

4. 重启 Codex **应用**，并新开 `codex` 会话。官方说明：Codex 在启动时构建模型列表；已有线程会保持它启动时所在的 provider，经 Magpie 启动的线程在拿掉 Magpie 后不能按原样打开。

## Magpie 可能写入的配置形状

下面摘自官方文档的**形状说明**，用来核对 Magpie 是否已经写入，而不是让你手抄一套密钥。示例中的模型名是上游页面自己的 DeepSeek 例子，**不要**把它当作 Google 型号。网关 Key 会出现在实际文件里，不要复制到本仓库。

当 Magpie 成为 Codex 的 provider 时，官方给出的形状是：

```toml
model = "deepseek/deepseek-v4-pro"
model_provider = "magpie"
model_catalog_json = "/Users/you/.codex/magpie-models.json"

[model_providers.magpie]
name = "magpie"
base_url = "http://127.0.0.1:3425/v1"
wire_api = "responses"
```

官方并写明：该表还会带上网关 Key 和相应头；供应商密钥留在 Magpie。已登录 ChatGPT 时，通常只在顶部设置 `openai_base_url` 和 `model`，Codex 自带模型仍走用户的 ChatGPT 登录，Magpie 的模型出现在 `/model` 里；`[model_providers.magpie]` 一旦写过会留下。以改完后的本机文件为准。默认网关地址常为上述值，端口以本机 Magpie 设置为准。

核对应看：`wire_api` 为 `responses`；`base_url` 指向本机网关的 `/v1`；所选 `model` 等于本机实际 id；文件里若有网关 Key，确认它不是 Google 的 OAuth 令牌。发现不符合时，先回到 Magpie 界面或 `magpie` 命令，不要发明额外的配置键去「修好」。

## 回滚

在 Agents 页把 Codex 行改回它自己的模型，或运行：

```sh
magpie codex default
```

然后重启 Codex。官方说明：Magpie 会撤掉它所写的 `model_provider`、`model_catalog_json` 和基础 URL，并恢复原来的 provider 与模型。若必须用备份文件恢复，只恢复用户事先同意备份的那一份，且不要把备份提交到仓库。

## 本分支验收

- 在 Codex 的 `/model` 或等价界面中能看到所选的实际型号，但这只是前提，不是成功。
- 用该型号完成真实文字测试，检查状态、正文和结束事件，而不是只看 HTTP 200。
- 再做至少两轮真实工具交互；工具须在 Codex 侧执行，结果被模型接着使用。若官方或插件未覆盖、或实机失败的工具（包括 Codex 自带的自定义工具），标记为未验证。
- 重启应用并新开会话后，再做一轮文字测试。
- 若启用了多个 Google 账号，按总则做安全的切换测试，不要耗尽额度。
- 插件文档提到，部分 Codex／GPT-5 风格的系统提示行会被 Google 拒绝，插件会改写后再发送。若出现与提示词相关的 400／429，按 [troubleshooting.md](troubleshooting.md) 记录原文，不要自行再做一层伪装。

未在 Codex 里真正发过请求时，不宣称本分支完成。本包未对此链路做实机验收，报告中必须区分「上游文档已描述」和「本机已验证」。
