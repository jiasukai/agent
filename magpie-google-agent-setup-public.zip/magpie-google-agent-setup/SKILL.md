---
name: magpie-google-agent-setup
description: 当用户要把 Magpie 中通过 agy-cli 插件登录的 Google 账号，接入 Claude Desktop、Claude Code 或 Codex（CLI／应用），或维护这些接入、从旧 WSL 账号池或旧版本文档目录迁移时使用。覆盖官方 agy 登录、按客户端配置与验收、切换验证与回滚。不适用于未在本文说明的其他客户端直连，也不把「仅把本 Skill 装进 Codex」当成已完成 Google 模型接入。
---

# 用 Magpie 把 Google 账号接入 Claude 与 Codex

本文是一份可独立阅读的操作指南，也可作为支持 Skill 的代理所加载的 `SKILL.md`。目标是使用 Magpie 与社区插件 `@magpie-community/opencode-agy-cli-auth`（provider 一般为 `agy-cli`）已有的原生 Google 多账号能力，把账号实际开放的模型分别接入 Claude Desktop、Claude Code 和 Codex（CLI／应用）。

优先使用上述原生多账号能力，不要再默认部署自制 fleet、WSL worker 或额外本地网关。本文件不是 Magpie、Google、Anthropic 或 OpenAI 的官方产品，不捆绑这些程序、账号或凭证。

本文不保证任意代理都能自动完成全部步骤，也不把模型说成可直连任意聊天客户端。已文档化的接入目标只有上述三个客户端，且都经由本机 Magpie 网关。Claude 分支与 Codex 分支的 API、配置文件、重启方式和回滚命令不同，必须分开处理。

## 角色区分

- **执行代理**：正在阅读或加载本指南、协助检查与操作的 AI 代理。它不是请求链路上的模型服务。即使执行代理碰巧是 Codex，也不等于已经把 Codex 配成使用 Google 账号模型。
- **被配置的客户端**（可只做其中一条，也可两条都做，但须分别验收）：
  - Claude Desktop 和／或 Claude Code：请求为 Anthropic Messages，指向本机网关。
  - Codex CLI／应用：请求为 OpenAI Responses，指向本机网关的 `/v1`。
- **账号本人**：必须在官方 Google 页面完成登录与验证。执行代理不得代填密码、验证码，也不得把凭证写入仓库、对话记录或本包。

## 如何使用本包

无 Skill 加载器时：把本文件当作普通 Markdown 阅读，并按需打开下方参考文档，按章节执行或指导用户执行。

支持 Skill 的代理：将仓库中的 `magpie-google-agent-setup` 文件夹，按该代理自己的 Skill 安装方式放入其技能目录。本包不规定或猜测其他产品的技能目录路径。复制前先查看目标目录是否已有同名文件夹，或旧名 `magpie-local-account-pool`、`magpie-claude-multi-account`；存在时不要覆盖，见 [旧名与并存](#旧名与并存)。

某一产品的技能目录、`$` 调用语法或 `agents/openai.yaml` 只是「执行代理要加载本 Skill」时的可选适配，不是把 Codex 配成目标客户端的前提。Codex 作为执行代理时的加载方式见 [可选适配：用 Codex 加载本 Skill](#可选适配用-codex-加载本-skill)。把 Google 模型接到 Codex 客户端，见 [references/clients-codex.md](references/clients-codex.md)。

## 能力与权限

开始前先确认执行代理实际具备的工具，再选择工作方式。不要声称所有代理都能无条件自动执行。

- **具备终端、文件或本机检查能力**：可代为查询已安装的 Magpie／插件／agy／客户端版本、阅读本机 help、按用户同意备份待改配置、运行用户明确同意且本文已写明的 Magpie 命令，并整理验收证据。仍须在官方登录等人工步骤处停下来。
- **只能对话、没有本机工具**：不要假装已经改过配置。改为逐步指导用户在本机完成操作，请用户回传脱敏的版本、界面状态和错误原文，再判断下一步。
- **权限不足或未获授权**：只做只读说明和清单，不改配置、不安装软件、不触达凭证目录。

无论哪种方式，官方 Google 登录、二次验证，以及各客户端里需要人工点击的安全确认，都必须由账号本人在相应界面完成。

## 输入、输出与停点

**建议输入（缺失则先向用户确认，不要假设）：**

- 目标机器与操作系统；已装或计划安装的 Magpie、agy、插件及各客户端版本（未知则先查）。
- 要接入的客户端：Claude Desktop、Claude Code、Codex，或其中若干（须分别验收）。不要默认「只要配了 Claude 就等于 Codex 也能用」。
- 要启用的 Google 账号范围，以及各账号要验证的目标模型。模型 ID 必须来自该账号在 Magpie／agy 中实际开放的列表，禁止使用本文未给出的示例型号去猜测。
- 是否存在旧版自制 WSL 账号池，是否需要保留可回滚状态。
- Codex 若已登录 ChatGPT，或已有自定义 `config.toml`，须在改动前说明，以便备份。
- 本机网络出口／VPN 是否已由用户管理（默认保留，不在请求范围外改出口）。

**输出：**

- 实际版本与本机发现结果（或由用户回传的等价信息），包括实际 provider id 和模型列表的脱敏摘要。
- 已完成与未完成的步骤，以及卡在哪一个停点。
- 按客户端分别列出已验证与未验证项、证据类型和回滚方法。
- 不要输出令牌、授权码、完整 OAuth URL、网关 Key、`config.toml`／`settings.json` 中的密钥、日志全文或未脱敏的账号标识。

**必须停下来交给账号本人的节点：**

1. Google 官方登录与任何验证／`VALIDATION_REQUIRED` 流程：只让官方流程生成当次链接或提示，由用户在官方页面登录，并把授权码回填到同一个等待中的流程。不要在本指南或对话中保存固定 OAuth URL、client secret、过期 state 或个人授权码。
2. 需要用户选择的安装盘符、是否升级、是否停用旧 worker、是否清理旧 WSL 用户或凭证、是否改写已有 Codex／Claude 配置。
3. 客户端里的安全确认弹窗（例如 Claude 的 Auto 确认）：用户必须在该客户端通知中回答；对话里说「继续」不等于已经点击 Continue。
4. 任何将写入或替换本机凭证、网关 Key，或导入旧 token 的操作：须用户明确同意，且优先走官方重新登录。

## 阅读哪些参考文档

- 新安装或添加 Google 账号（共用）：读 [references/setup.md](references/setup.md)。
- 接入 Claude Desktop／Claude Code：读 [references/clients-claude.md](references/clients-claude.md)。
- 接入 Codex CLI／应用：读 [references/clients-codex.md](references/clients-codex.md)。
- 已有 WSL 账号池，或旧文档目录迁移：先读 [references/migration.md](references/migration.md)。
- 报错、限额、上下文或切换异常：读 [references/troubleshooting.md](references/troubleshooting.md)。
- 版本依据、架构与验收边界：读 [references/architecture.md](references/architecture.md)。

## 执行原则

先记录实际 Magpie、agy 和插件版本，以及当前客户端入口、网络代理、可用账号数量与模型。核对当前上游文档和本机 help；不能把 Magpie 一般支持多账号，直接当作任意旧版插件已支持隔离登录。

使用 `@magpie-community/opencode-agy-cli-auth`。当前插件文档中的 provider id 为 `agy-cli`，模型写成 `agy-cli/<实际模型>`。部分 Magpie 页面仍写 `antigravity/…`；安装后以 `magpie models` 和 Providers 页的实际 id 为准，不要混用或臆造型号。在 Providers 中使用 Add another account，选择添加另一个 Google 账号，每个账号应单独一行。让官方登录流程生成当次链接，用户在 Google 页面登录，授权码回填同一个等待中的流程。不要在本文件中放固定 OAuth URL、client secret、过期 state 或个人授权码。

不要为新安装使用已退役的「在 Magpie 里直接登录 Antigravity」。上游说明那种方式会被 Google 封号；当前应安装上述插件，由本机 `agy` 登录，使请求以 agy 自己的身份发出。插件并不能保证账号一定不受限制。

被配置的客户端接到本地 Magpie。agy-cli 插件本身接收 Anthropic Messages，再调用官方 `agy acp`。Codex 只讲 OpenAI Responses，因此 Codex 分支依赖 Magpie 网关把 Responses 翻译成插件所使用的 API。这是上游文档中的网关能力，但本包未做端到端实测，验收时必须在目标客户端上得到真实请求证据。这不代表 Google 对第三方接入或账号轮换的支持承诺。不要仿冒客户端身份、修改资格校验或自己实现 Google 内部模型接口。

模型必须来自账号实际开放的 ACP 列表，不能把所有账号的模型并集当成每个账号均可用，也不能把 `agy models` 列出但未向该客户端开放的型号当成可用。Opus/Sonnet 是 Claude 的档位或显示配置，不会把 Gemini 变成 Claude，也不会把模型变成 Codex 自带的 OpenAI 型号；显示名应明确实际模型。原生同 provider 多账号不要求为每个账号创建一个 routing group；仅在用户需要多个模型或明确的路由策略时加组。

当前插件历史重放默认 `AGY_BRIDGE_MAX_PROMPT_BYTES=114688`（112 KiB）。保留默认，不能因 1M 模型上下文而提升至 MB 级；恢复不了的历史应明确告知。不要另写提示词删改器，或删除用户权限指令来求成功。并发及超时按当前插件和实际负载选择，不照抄旧包固定的 4 或无限并发。

网络代理地址、安装盘符和端口从目标机发现，不沿用源电脑。默认网关常为 `http://127.0.0.1:3425`，以实际配置为准。保留用户已有 VPN，只有在请求范围内才改网络出口。凭证目录路径跟随当前 OS 和插件实现；账号私有文件不等于加密文件。Google 登录凭证与各客户端里的网关 Key 是不同东西：前者留在 agy／插件侧，后者由 Magpie 写入对应客户端配置，不要写进本仓库。

使用客户端期间 Magpie（或其守护进程）需要在运行，因为网关随应用提供。不要另外搭建未经本文引用的翻译代理，也不要修改应用源代码来「补齐」兼容性。

## 完成标准

共用（在进入各客户端验收前）：

- 每个已启用账号独立登录，身份不同；`magpie models` 或等价界面列出的目标模型来自该账号实际开放的列表。

Claude Desktop／Claude Code 分支（只配置了这条才验收这条）：

- 被配置的 Claude 客户端完成两轮真实工具交互，工具在该客户端执行，返回结果被模型正确使用。
- 多轮测试同时识别旧参考信息与最新唯一要求；重启该客户端后账号和模型仍可用。

Codex 分支（只配置了这条才验收这条）：

- 在 Codex 中选用实际列出的 `agy-cli/<实际模型>`（或以本机为准的等价 id），完成真实文字测试。
- 再完成至少两轮真实工具交互；工具在 Codex 侧执行，返回结果被模型正确使用。若某类 Codex 自带工具（例如其自定义 patch 工具）失败，记为该工具未验证，不要改写成「已全面支持」。
- 重启 Codex 应用并新开会话后，仍能选中同一模型并完成一轮文字测试。

共用的切换与证据：

- 在隔离测试入口模拟 429，或利用现有真实额度错误，核对下一账号接手和模型一致；不得耗尽账号额度制造故障。若本版本没有隔离手段，标记自动切换未验证，不修改生产凭证伪造错误。
- 检查 HTTP 状态、SSE error、正文、工具事件及终止事件。HTTP 200、模型列表可见、`/model` 里出现名称，或单独的 end_turn，都不能证明成功。
- 一条客户端通过，不得自动宣布另一条也通过。

报告已验证与未验证项目、实际版本和回滚方法。用户未登录，或未在被验收的那个客户端发送请求时，不宣称该分支完成。本包不携带程序、令牌或运行账号，不授权向外发布用户配置。

## 旧名与并存

本指南的目录和 Skill 名为 `magpie-google-agent-setup`。更早的文档包曾使用 `magpie-local-account-pool` 和 `magpie-claude-multi-account`。若目标技能目录或工作区里已有这些旧名文件夹，不要删除或覆盖它们来安装新版。应使用新目录名并存，完成验收后，再由用户决定是否自行移除旧副本。

## 可选适配：用 Codex 加载本 Skill

若执行代理是 Codex，且希望按 Skill 加载：可将 `magpie-google-agent-setup` 文件夹复制到 `~/.codex/skills/`（Windows 通常是 `%USERPROFILE%\.codex\skills\`）。复制前检查该目录下是否已有同名或上述旧名，有则不要覆盖。新对话中可选用类似如下调用，但这不是把 Codex 配成目标客户端的步骤，也不是其他代理的前提：

```text
$magpie-google-agent-setup 帮我用 Magpie 把已登录的 Google 账号接入 Claude Desktop／Claude Code 和 Codex，先检查版本和当前配置。
```

`agents/openai.yaml` 仅供 Codex 界面显示名称与默认提示，其他代理可以忽略。
